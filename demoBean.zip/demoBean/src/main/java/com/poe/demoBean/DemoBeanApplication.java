package com.poe.demoBean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBeanApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoBeanApplication.class, args);
	}

}
