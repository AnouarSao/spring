package com.poe.demoBean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBeanApplicationTests {

	@Test
	void contextLoads() {
	}

}
